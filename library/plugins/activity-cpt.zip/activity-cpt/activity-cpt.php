<?php
/**
Plugin Name: Activités


from codex : http://codex.wordpress.org/Function_Reference/register_post_type

**/

defined( 'ABSPATH' ) or die( 'No script kiddies please!' );


add_action( 'init', 'activites_init' );
add_image_size( 'tiny-size', 40, 40 );
/**
 * Register a book post type.
 *
 * @link http://codex.wordpress.org/Function_Reference/register_post_type
 */
function activites_init() {
	$labels = array(
		'name'               => _x( 'Activités', 'post type general name', 'your-plugin-textdomain' ),
		'singular_name'      => _x( 'Activité', 'post type singular name', 'your-plugin-textdomain' ),
		'menu_name'          => _x( 'Activités', 'admin menu', 'your-plugin-textdomain' ),
		'name_admin_bar'     => _x( 'Activité', 'add new on admin bar', 'your-plugin-textdomain' ),
		'add_new'            => _x( 'ajouter nouvelle', 'Activité', 'your-plugin-textdomain' ),
		'add_new_item'       => __( 'nouvelle activité', 'your-plugin-textdomain' ),
		'new_item'           => __( 'nouvelles Activités', 'your-plugin-textdomain' ),
		'edit_item'          => __( 'Editer Activités', 'your-plugin-textdomain' ),
		'view_item'          => __( 'Voir Activités', 'your-plugin-textdomain' ),
		'all_items'          => __( 'Toutes les activités', 'your-plugin-textdomain' ),
		'search_items'       => __( 'Chercher Activités', 'your-plugin-textdomain' ),
		'parent_item_colon'  => __( 'Activités parentes:', 'your-plugin-textdomain' ),
		'not_found'          => __( 'Pas d\'Activités trouvées.', 'your-plugin-textdomain' ),
		'not_found_in_trash' => __( 'Pas d\'activités dans la poubelle.', 'your-plugin-textdomain' )
	);

	$args = array(
		'labels'             => $labels,
                'description'        => __( 'Description.', 'your-plugin-textdomain' ),
		'public'             => true,
		'publicly_queryable' => true,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'query_var'          => true,
		'rewrite'            => array( 'slug' => 'activites' ),
		'capability_type'    => 'post',
		'has_archive'        => true,
		'hierarchical'       => false,
		'menu_position'      => null,
		'supports'           => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments' )
	);

	register_post_type( 'activite_cpt', $args );
}


function my_rewrite_flush() {
    // First, we "add" the custom post type via the above written function.
    // Note: "add" is written with quotes, as CPTs don't get added to the DB,
    // They are only referenced in the post_type column with a post entry, 
    // when you add a post of this CPT.
    activites_init();

    // ATTENTION: This is *only* done during plugin activation hook in this example!
    // You should *NEVER EVER* do this on every page load!!
    flush_rewrite_rules();
}
register_activation_hook( __FILE__, 'my_rewrite_flush' );

// add taxo for activite

function activite_taxonomies() {
     register_taxonomy('activites_tags', 'activite_cpt', array('label' => 'Tags','show_ui' => true,
    'update_count_callback' => '_update_post_term_count',
    'query_var' => true
     ));
}
add_action( 'init', 'activite_taxonomies');


/*********************** admin cols *****************/

//add id to all our posts 

add_filter( 'manage_posts_columns', 'revealid_add_id_column', 5 );
add_action( 'manage_posts_custom_column', 'revealid_id_column_content', 5, 2 );


function revealid_add_id_column( $columns ) {
   $columns['revealid_id'] = 'ID';
   return $columns;
}

function revealid_id_column_content( $column, $id ) {
  if( 'revealid_id' == $column ) {
    echo $id;
  }
}


$custom_post_types = get_post_types( 
   array( 
      'public'   => true, 
      '_builtin' => false
   ), 
   'names'
); 

foreach ( $custom_post_types as $post_type ) {
	add_action( 'manage_edit-'. $post_type . '_columns', 'revealid_add_id_column' );
	add_filter( 'manage_'. $post_type . '_custom_column', 'revealid_id_column_content' );
}

// adding cols to the cpt

add_filter( 'manage_edit-activite_cpt_columns', 'my_columns' );

function my_columns( $columns ) {
    $columns['Tags'] = 'Tags';
    $columns['Image'] = 'Image';
    $columns['Quand'] = 'Quand';
    unset( $columns['author'] );
    return $columns;
}

add_action( 'manage_activite_cpt_posts_custom_column', 'populate_columns', 10, 2);

function populate_columns( $column, $post_id ) {

	if('revealid_id' == $column) {
	//echo $post_id;
	
	}
	
     else if ( 'Tags' == $column ) {
        $the_custom_tags = get_the_term_list ( $post_id, 'activites_tags' ) ;
       	echo $the_custom_tags;
    }
    
    
    else if ('Image' == $column){
    
    echo get_the_post_thumbnail( $post_id, 'tiny-size' );
    
    } 
    
    else if ('Quand' == $column) {
    
   echo rwmb_meta( 'activite_date_date', $post_id );
   

    
    }
    
}

add_filter( 'manage_edit-activite_cpt_sortable_columns', 'sort_me' );

function sort_me( $columns ) {
    $columns['Tags'] = 'Tags';
    $columns['Quand'] = 'Quand';
 
    return $columns;
}


/*** setup custom field for Date ***/

add_filter( 'rwmb_meta_boxes', 'ocr_register_meta_boxes' );
function ocr_register_meta_boxes() {
    // Code
    $prefix = 'activite_date_';
    
    $meta_boxes[] = array(
        'id'         => 'duree',
        'title'      => __( 'Date de l\'activite', 'your-plugin-textdomain' ),
        'post_types' => array( 'activite_cpt' ),
        'context'    => 'normal',
        'priority'   => 'high',
        'fields' => array(
			array(
				'name' => __( 'Date', 'rwmb' ),
				'id'   => $prefix . 'date',
				'type' => 'date',

				// jQuery date picker options. See here http://jqueryui.com/demos/datepicker
				'js_options' => array(
					'appendText'      => __( '(yyyy-mm-dd)', 'rwmb' ),
					'autoSize'        => true,
					'buttonText'      => __( 'Select Date', 'rwmb' ),
					'dateFormat'      => __( 'yy-mm-dd', 'rwmb' ),
					'numberOfMonths'  => 2,
					'showButtonPanel' => true,
				),
			),
			
			
		),
	
    );


	return $meta_boxes;
}

/** required fieds **/
function add_admin_scripts( $hook ) {

    global $post;

    if ( $hook == 'post-new.php' || $hook == 'post.php' ) {
        if ( 'activite_cpt' === $post->post_type ) {     
            wp_enqueue_script(  'myscript', plugins_url('/js/required.js', __FILE__  ),array('jquery'),'1', true);
        }
    }
}
add_action( 'admin_enqueue_scripts', 'add_admin_scripts', 10, 1 );

/*********************** /admins cols *************/
// Add a Custom Post Type to a feed
function add_cpt_to_feed( $qv ) {
  if ( isset($qv['feed']) && !isset($qv['post_type']) )
    $qv['post_type'] = array('post', 'activite_ctp');
  return $qv;
}

add_filter( 'request', 'add_cpt_to_feed' );


///// add shortcodes
//

add_shortcode('singulier', 'single_post_shortcode');

//add to tinyMCE all my shortcodes
function register_button( $buttons ) {
   array_push( $buttons, "|", "singulier" );
   array_push( $buttons, "|", "bytags" );
   
   return $buttons;
}

function add_plugin( $plugin_array ) {
   $plugin_array['singulier'] = plugins_url('/js/shortcode.js', __FILE__  );
   $plugin_array['bytags'] = plugins_url('/js/bytags.js', __FILE__  );
   return $plugin_array;
}
function my_singular_button() {

   if ( ! current_user_can('edit_posts') && ! current_user_can('edit_pages') ) {
      return;
   }

   if ( get_user_option('rich_editing') == 'true' ) {
      add_filter( 'mce_external_plugins', 'add_plugin' );
      add_filter( 'mce_buttons', 'register_button' );
   }

}

add_action('init', 'my_singular_button');

/*** debug ***/

/**** \debug ***/

function single_post_shortcode($atts){

	global $posts;
	$default = array( 'id'=> 60,
				'type'  => ['activite_cpt' , 'post'],
    			'post_type' => ['activite_cpt' , 'post'],
    			'limit'     => 1,
    			'status'    => 'publish'
		);
		
	$r = shortcode_atts( $default, $atts);
	extract($r);
	
	$post_types = get_post_types();
	
	$args = array(
    'p' => $id,
    'type'  => $post_types,
    'post_type' => $post_types,
    'limit'     => 1,
    'status'    => 'publish'
  );
  
  $posts = get_posts( $args );
  if( count($posts) ):
  
  	$return = "<div class='row'>";
    
    	foreach( $posts as $post ): setup_postdata( $post );
    	$the_ID = $post->ID;
    	$return .='<div class="col-xs-12">';
      	$return .='<div class="card"><div class="card-block">';
      	$return .='<h4 class="card-title">';
      	$return .= '<a href="'.get_permalink( $the_ID ) .'" >'  . get_the_title( $the_ID ) . '</a>';
      	$return .= '</h4><div class="entry-img">';
      	if ( has_post_thumbnail($the_ID) ) :
			$return .= get_the_post_thumbnail( $the_ID, 'card-size' ); 
	 	endif;
      	$return .='</div></div><div class="entry-container"><header class="entry-header"></header><div class="entry-content">';
	  	$return .= get_the_excerpt(); 
	  	$return .= '<p><a class="read-more" href="' . get_permalink( $the_ID ) . '">'.__( 'Lire la suite', 'ocr_wp' ).'</a></p>';
	  	$return .= '</div><footer class="entry-footer"></footer><!-- .entry-footer --></div> <!-- .entry-container --></div>';
      	$return .='</div>';
    endforeach; wp_reset_postdata();
    
  $return .= '</div>';
  else :
    $return = '<p></p>';
  endif;
	
  return $return;
}
/* ------------------------------------*/
//by custom-tags
add_shortcode( 'custom_posts', 'activite_custom_posts' );
function activite_custom_posts( $atts ){
  global $post;
  $default = array(
    'type'      => 'post',
    'post_type' => '',
    'limit'     => 10,
    'status'    => 'publish',
    'tag' =>null,
    'tax_query' => array(
    				array(
    				
    				'taxonomy' => 'activites_tags',
			'field'    => 'slug',
			'terms'    => 'exterieuree',
    				)
    )
  );
  $r = shortcode_atts( $default, $atts );
  
  extract( $r );
  
  
  

  if( empty($post_type) )
    $post_type = $type;

  $post_type_ob = get_post_type_object( $post_type );
  if( !$post_type_ob )
    return '<div class="warning"><p>pas de post de ce type <em>' . $post_type . '</em> trouvé.</p></div>';

  $args = array(
    'post_type'   => $post_type,
    'numberposts' => $limit,
    'post_status' => $status,
  );
  
  if (isset( $tag ) && $tag !='' ) {
  
  $args['tax_query'] = array(
    				array(
    				
    				'taxonomy' => 'activites_tags',
			'field'    => 'slug',
			'terms'    => $tag,
    				)
    );
  
  }

  $posts = get_posts( $args );
  if( count($posts) ):
  
  $return = "<div class='row'>";
    
    foreach( $posts as $post ): setup_postdata( $post );
    
      $return .='<div class="col-xs-12 col-md-4">';
      $return .='<div class="card"><div class="card-block">';
      $return .='<h4 class="card-title">';
       $return .= '<a href="'.get_permalink() .'" >' . get_the_title() . '</a>';
      $return .= '</h4><div class="entry-img">';
      if ( has_post_thumbnail() ) :
		$return .= get_the_post_thumbnail( get_the_ID(), 'card-size' ); 
	 endif;
      
      
      $return .='</div></div><div class="entry-container"><header class="entry-header"></header><div class="entry-content">';
	  $return .= get_the_excerpt(); 
	  $return .= '<p><a class="read-more" href="' . get_permalink( $the_ID ) . '">'.__( 'Lire la suite', 'ocr_wp' ).'</a></p>';
	  $return .= '</div><footer class="entry-footer"></footer><!-- .entry-footer --></div> <!-- .entry-container --></div>';
      $return .='</div>';
    endforeach; wp_reset_postdata();
    
  $return .= '</div>';
  else :
    $return = '<p></p>';
  endif;
	
  return $return;
 
}