(function() {
   tinymce.create('tinymce.plugins.singulier', {
      init : function(ed, url) {
         ed.addButton('singulier', {
            title : 'carte single post',
            image : url+'/singular.png',
            onclick : function() {
               var idpost = prompt("id du post", "1");
              

               
                  if (idpost != null && idpost != '')
                     ed.execCommand('mceInsertContent', false, '[singulier id="'+idpost+'"]');
                  
               
            }
         });
      },
      createControl : function(n, cm) {
         return null;
      },
      getInfo : function() {
         return {
            longname : "singulier ",
            author : 'Stan',
            authorurl : 'https://code-codec.fr',
            infourl : '',
            version : "1.0"
         };
      }
   });
   tinymce.PluginManager.add('singulier', tinymce.plugins.singulier);
   
})();