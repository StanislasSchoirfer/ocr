(function() {
   
   /* pattern [custom_posts type='activite_cpt' tag='Musée'] */
   
   tinymce.create('tinymce.plugins.bytags', {
      init : function(ed, url) {
         ed.addButton('bytags', {
            title : 'cartes activite par tags',
            image : url+'/bytags.png',
            onclick : function() {
               var postType = prompt("type du post", "activite_cpt");
               var postTag = prompt("tag du post", "Musée");
              

               
                  if (postTag != null && postTag != '')
                     ed.execCommand('mceInsertContent', false, '[custom_posts type="'+postType+'" '+' tag="'+postTag+'" ' +']');
                  
               
            }
         });
      },
      createControl : function(n, cm) {
         return null;
      },
      getInfo : function() {
         return {
            longname : "byTag ",
            author : 'Stan',
            authorurl : 'https://code-codec.fr',
            infourl : '',
            version : "1.0"
         };
      }
   });
   tinymce.PluginManager.add('bytags', tinymce.plugins.bytags);
})();