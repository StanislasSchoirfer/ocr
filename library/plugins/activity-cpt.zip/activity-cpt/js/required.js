jQuery("#publish").on('click', function(){ 
    
    //search the required fields
    
	var $val = jQuery("#duree .rwmb-date-wrapper .rwmb-input input").val();
	
	if(!$val){
	alert('le champ date doit être rempli');
    return false;
    }
});